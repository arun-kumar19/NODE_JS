const express = require('express');
const bodyParser = require('body-parser');
const router = express.Router();
const app = express();

const homeController=require('../controllers/home');

app.use(bodyParser.urlencoded({ extended: false }));

router.get('/', homeController.getProducts);

router.get('/loadcontent', homeController.loadContent);
router.post('/addproduct', homeController.getAddProduct);
router.delete('/deleteproduct/:prodid', homeController.deleteProduct);

module.exports=router;