const Sequelize=require('sequelize');

//it creates a connection pool
const sequelize=require('../util/database');

const expense=sequelize.define('sellerproduct',{
id:{
  type:Sequelize.INTEGER,
  autoIncrement:true,
  allowNull:false,
  primaryKey:true
},
price:{
type:Sequelize.INTEGER,
allowNull:false
},
product:{
  type:Sequelize.STRING,
  allowNull:false
}
});
module.exports=expense;


