const { json } = require('body-parser');
const Stock=require('../models/stockdetails');
const {Op} = require('sequelize');

exports.getProducts=(req,res)=>{
  
  res.render('index',{
    path:'/'
  })
}

exports.getAddProduct = async (req, res) => {
        
        const jsonData = req.body;
        console.log('jsonResponse=',req.body);
    try {
        const price=jsonData.price;
        const product = jsonData.product;
        console.log('values=[',price,product,']');
      const stock = await Stock.create({price,product});
      console.log('abc=',stock);
      
      if (!stock) {
        return res.status(400).json({ message: 'Something went wrong' });
      }
      console.log('stock saved successfully');
      //const stocks=await Stock.findAll();
       // console.log('new stocks=',stocks);
    res.json(stock); 
    } catch (error) {
      console.log('error=',error.message);
res.status(500).json({ message: 'Internal server error' });
    }
  };


exports.loadContent = async (req, res) => {
    const arr=[];
    try {
  const stocks=await Stock.findAll();
   // console.log(expenses);
    stocks.forEach(stock=>{
            arr.push(stock.toJSON());
    }) 
  //console.log('expenses=',arr);
res.json(arr); // Send the response inside the try block
} catch (error) {
  //console.log('error=',error.message);
res.status(500).json({ message: 'Internal server error' });
}
};
  
exports.deleteProduct=async (req,res)=>{

        const prodid=req.params.prodid;
        let deletedProduct;
        console.log('Delete Request Prodcut Id=',prodid);
    try{
        const product=await Stock.findByPk(prodid)
        
        if(!product){
            res.status(400).json({message:'something went wrong'});
        }
        deletedProduct= await product.destroy();
     console.log('post delete resonse=',deletedProduct);
    
    }catch(error){
        console.log(error);
    }
    res.json(deletedProduct);

}

